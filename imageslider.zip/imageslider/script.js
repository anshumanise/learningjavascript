const imageUrls = [
    'https://picsum.photos/id/10/800/450',
    'https://picsum.photos/id/20/800/450',
    'https://picsum.photos/id/30/800/450',
    'https://picsum.photos/id/40/800/450',
    'https://picsum.photos/id/50/800/450'
];

let currentIndex = 0;

const displayImage = document.getElementById('carouselImage');
const prevBtn = document.getElementById('prevButton');
const nextBtn = document.getElementById('nextButton');

/**
 * FIX: Layout ko theek karne wala function
 * Yeh buttons ko image ke upar left aur right mein set kar dega
 */
function fixButtonLayout() {
    const container = document.querySelector('.carousel-container');
    if (container) {
        container.style.position = 'relative';
        container.style.display = 'flex';
        container.style.alignItems = 'center';
        container.style.justifyContent = 'center';
    }

    if (prevBtn && nextBtn) {
        // Common styles for both buttons
        [prevBtn, nextBtn].forEach(btn => {
            btn.style.position = 'absolute';
            btn.style.top = '50%';
            btn.style.transform = 'translateY(-50%)';
            btn.style.zIndex = '10';
            btn.style.padding = '15px';
            btn.style.cursor = 'pointer';
            btn.style.backgroundColor = 'rgba(0,0,0,0.5)';
            btn.style.color = 'white';
            btn.style.border = 'none';
        });

        // Specific positions
        prevBtn.style.left = '10px';
        nextBtn.style.right = '10px';
    }
}

function updateDisplay() {
    if (!displayImage) return;
    
    displayImage.classList.add('fade-out');
    setTimeout(() => {
        displayImage.src = imageUrls[currentIndex];
        displayImage.classList.remove('fade-out');
    }, 200);

    // Boundary check for visual feedback
    prevBtn.style.display = (currentIndex === 0) ? "none" : "block";
    nextBtn.style.display = (currentIndex === imageUrls.length - 1) ? "none" : "block";
}

if (nextBtn) {
    nextBtn.addEventListener('click', () => {
        // Cycle back NOT allowed: Check if we are NOT at the last image
        if (currentIndex < imageUrls.length - 1) {
            currentIndex++;
            updateDisplay();
        }
    });
}

if (prevBtn) {
    prevBtn.addEventListener('click', () => {
        // Cycle back NOT allowed: Check if we are NOT at the first image
        if (currentIndex > 0) {
            currentIndex--;
            updateDisplay();
        }
    });
}

// Initialization
window.onload = () => {
    fixButtonLayout(); // CSS mismatch ko JS se theek kiya
    if (displayImage) {
        displayImage.src = imageUrls[currentIndex];
        // Pehli image par Previous button chhupa do
        prevBtn.style.display = "none"; 
    }
};