let questionRotationInterval;
let isFetchingEnabled = true;

const questionDisplay = document.querySelector('.question');
const stopBtn = document.querySelector('.stop-button');

/**
 * Task 1: Fetch Random Question
 * Makes a GET request to the Trivia API and updates the UI.
 */
async function fetchRandomQuestion() {
    // Only proceed if the rotation hasn't been stopped
    if (!isFetchingEnabled) return;

    try {
        const response = await fetch("https://the-trivia-api.com/api/questions?limit=1");
        
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        
        /** 
         * FIX: Most Trivia APIs return an array of objects.
         * We extract the 'question' property from the first object.
         */
        const questionText = Array.isArray(data) ? data[0].question : data.question;

        if (questionText) {
            questionDisplay.textContent = questionText;
        } else {
            throw new Error('Question field missing in response');
        }
    } catch (error) {
        console.error('Fetch Error:', error);
        questionDisplay.textContent = "Error loading question. Please try again.";
    }
}

/**
 * Task 2: Start Question Rotation
 * Triggers an immediate fetch and sets up the 5-second interval.
 */
function startQuestionRotation() {
    isFetchingEnabled = true;
    
    // Initial call to show first question immediately
    fetchRandomQuestion();
    
    // Refresh every 5 seconds (5000ms)
    questionRotationInterval = setInterval(fetchRandomQuestion, 5000);
}

/**
 * Task 3: Stop Button Functionality
 * Halts rotation, sets a flag, and updates UI styles.
 */
// function handleStopClick() {
//     // 1. Clear the timer
//     clearInterval(questionRotationInterval);
    
//     // 2. Set flag to prevent any pending API calls from updating the UI
//     isFetchingEnabled = false;
    
//     // 3. UI Changes
//     stopBtn.classList.add('stopped');
//     stopBtn.disabled = true;
//     questionDisplay.textContent = "Questions Stopped"; 
//     stopBtn.textContent = "Stopped";
// }
function handleStopClick() {
    // 1. Clear the timer
    clearInterval(questionRotationInterval);

    // 2. Set flag to prevent pending API calls
    isFetchingEnabled = false;

    // 3. UI Changes
    stopBtn.classList.add('stopped');
    stopBtn.disabled = true;

    // CHANGE THIS LINE:
    // From: questionDisplay.textContent = "Questions Stopped";
    // To:
    questionDisplay.textContent = "Questions stopped."; 

    stopBtn.textContent = "Stopped";
}

// Add event listener when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    startQuestionRotation();

    if (stopBtn) {
        stopBtn.addEventListener('click', handleStopClick);
    }
});
