const imageUrls = [
    'https://picsum.photos/id/10/800/450',
    'https://picsum.photos/id/20/800/450',
    'https://picsum.photos/id/30/800/450',
    'https://picsum.photos/id/40/800/450',
    'https://picsum.photos/id/50/800/450'
];

let currentIndex = 0;

const displayImage = document.getElementById('carouselImage');
const prevBtn = document.getElementById('prevButton');
const nextBtn = document.getElementById('nextButton');

// Function to fix layout issues dynamically without touching CSS file
function fixLayout() {
    const container = document.querySelector('.carousel-container');
    if (container) {
        container.style.position = 'relative';
        container.style.display = 'flex';
        container.style.alignItems = 'center';
        container.style.justifyContent = 'center';
        container.style.maxWidth = '800px';
        container.style.margin = 'auto';
    }

    if (prevBtn && nextBtn) {
        // Left Button positioning
        prevBtn.style.position = 'absolute';
        prevBtn.style.left = '10px';
        prevBtn.style.zIndex = '10';

        // Right Button positioning
        nextBtn.style.position = 'absolute';
        nextBtn.style.right = '10px';
        nextBtn.style.zIndex = '10';
    }
}

function updateDisplay() {
    if (!displayImage) return;
    
    displayImage.classList.add('fade-out');
    setTimeout(() => {
        displayImage.src = imageUrls[currentIndex];
        displayImage.classList.remove('fade-out');
    }, 200); 
}

if (nextBtn) {
    nextBtn.addEventListener('click', () => {
        currentIndex = (currentIndex + 1) % imageUrls.length;
        updateDisplay();
    });
}

if (prevBtn) {
    prevBtn.addEventListener('click', () => {
        currentIndex = (currentIndex - 1 + imageUrls.length) % imageUrls.length;
        updateDisplay();
    });
}

window.onload = () => {
    fixLayout(); // Layout theek karne wala function call kiya
    if (displayImage) {
        displayImage.src = imageUrls[currentIndex];
    }
};